package ru.echo.menu;

/** Six chest rows, numbered from zero. Center lobby occupies four rows. */
public final class MenuLayout {
    private MenuLayout() {}
    public enum Button { WORLD, ACCESSORIES, CASES, FARMS, LOBBY, END, NONE }
    public static Button buttonAt(int slot) {
        if (slot < 0 || slot >= 54) return Button.NONE;
        int row = slot / 9;
        int column = slot % 9;
        if (column < 3) return row < 3 ? Button.WORLD : Button.FARMS;
        if (column < 6) return row < 2 ? Button.ACCESSORIES : Button.LOBBY;
        return row < 3 ? Button.CASES : Button.END;
    }
}
