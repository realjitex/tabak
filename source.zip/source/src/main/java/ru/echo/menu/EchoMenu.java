package ru.echo.menu;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public final class EchoMenu extends JavaPlugin implements Listener {
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private NamespacedKey openerKey;
    private Component title;

    @Override public void onEnable() {
        saveDefaultConfig();
        openerKey = new NamespacedKey(this, "opener");
        loadTitle();
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
    }

    private void loadTitle() {
        String font = getConfig().getString("menu.font", "echo_menu_6c41323d:gui");
        int offset = Math.max(-256, Math.min(256, getConfig().getInt("menu.offset-x", -8)));
        String spacing = (offset < 0 ? "\uE001" : "\uE002").repeat(Math.abs(offset));
        // The overlay is unshadowed; it must not inherit vanilla's dark title color.
        title = Component.text(spacing + "\uE000", NamedTextColor.WHITE)
                .font(Key.key(font)).shadowColor(net.kyori.adventure.text.format.ShadowColor.none());
    }

    private static final class MenuHolder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private void open(Player player) {
        if (!player.hasPermission("echomenu.use")) {
            player.sendMessage(Component.text("Нет доступа к меню.", NamedTextColor.RED));
            return;
        }
        MenuHolder holder = new MenuHolder();
        holder.inventory = Bukkit.createInventory(holder, 54, title);
        // All slots intentionally stay empty. The font supplies the entire image.
        player.openInventory(holder.inventory);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("echomenu") && args.length > 0) {
            if (!sender.hasPermission("echomenu.admin")) {
                sender.sendMessage("Нет доступа.");
                return true;
            }
            if (args[0].equalsIgnoreCase("reload")) {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder) player.closeInventory();
                }
                reloadConfig();
                loadTitle();
                sender.sendMessage("EchoMenu: конфиг перезагружен.");
                return true;
            }
            if (args[0].equalsIgnoreCase("item") && sender instanceof Player player) {
                if (player.getInventory().firstEmpty() < 0) {
                    player.sendMessage(Component.text("Освободите слот в инвентаре."));
                    return true;
                }
                ItemStack item = new ItemStack(Material.COMPASS);
                item.editMeta(meta -> {
                    meta.displayName(Component.text("Выбор режимов", NamedTextColor.LIGHT_PURPLE).decoration(TextDecoration.ITALIC, false));
                    meta.getPersistentDataContainer().set(openerKey, PersistentDataType.BYTE, (byte) 1);
                });
                player.getInventory().addItem(item);
                return true;
            }
            sender.sendMessage("/echomenu [reload|item]");
            return true;
        }
        if (sender instanceof Player player) open(player);
        else sender.sendMessage("Эта команда доступна в игре.");
        return true;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder)) return;
        // Also blocks shift clicks, hotbar swaps, drops, double clicks, and creative cloning.
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getClick().isLeftClick() || event.getClick().isRightClick()) || event.isShiftClick()) return;
        MenuLayout.Button button = MenuLayout.buttonAt(event.getRawSlot());
        if (button == MenuLayout.Button.NONE) return;
        if (!player.hasPermission("echomenu.use")) return;
        long now = System.currentTimeMillis();
        if (now - cooldowns.getOrDefault(player.getUniqueId(), 0L) < 1000) return;
        cooldowns.put(player.getUniqueId(), now);
        if (button != MenuLayout.Button.WORLD && button != MenuLayout.Button.LOBBY) {
            message(player, "soon");
            return;
        }
        String destination = button == MenuLayout.Button.WORLD ? "world" : "lobby";
        // Inventory operations are deferred until the click transaction completes.
        Bukkit.getScheduler().runTask(this, () -> {
            if (!player.isOnline() || player.getOpenInventory().getTopInventory() != event.getView().getTopInventory()) return;
            player.closeInventory();
            travel(player, destination);
        });
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof MenuHolder) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;
        if (!item.getItemMeta().getPersistentDataContainer().has(openerKey, PersistentDataType.BYTE)) return;
        event.setCancelled(true);
        Bukkit.getScheduler().runTask(this, () -> { if (event.getPlayer().isOnline()) open(event.getPlayer()); });
    }

    private void travel(Player player, String destination) {
        String base = "destinations." + destination;
        String target = getConfig().getString(base + ".target", "").trim();
        String type = getConfig().getString(base + ".type", "SERVER");
        if (target.isEmpty()) { message(player, "not-configured"); return; }
        if (type.equalsIgnoreCase("WORLD")) {
            World world = Bukkit.getWorld(target);
            if (world == null) { message(player, "not-configured"); return; }
            player.teleportAsync(world.getSpawnLocation()).thenAccept(success -> {
                if (!success) getLogger().warning("Teleport failed for " + player.getUniqueId());
            });
        } else if (type.equalsIgnoreCase("SERVER")) {
            if (target.equals(getConfig().getString("current-server", ""))) {
                message(player, "already-here");
                return;
            }
            try {
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                try (DataOutputStream output = new DataOutputStream(buffer)) {
                    output.writeUTF("Connect");
                    output.writeUTF(target);
                }
                player.sendPluginMessage(this, "BungeeCord", buffer.toByteArray());
                message(player, "connecting");
            } catch (IOException exception) {
                getLogger().severe("Cannot encode destination: " + exception.getMessage());
                message(player, "not-configured");
            }
        } else message(player, "not-configured");
    }

    private void message(Player player, String name) {
        player.sendMessage(Component.text(getConfig().getString("messages." + name, name), NamedTextColor.LIGHT_PURPLE));
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) { cooldowns.remove(event.getPlayer().getUniqueId()); }

    @Override public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder) player.closeInventory();
        }
        getServer().getMessenger().unregisterOutgoingPluginChannel(this);
        cooldowns.clear();
    }
}
