import ru.echo.menu.MenuLayout;
import static ru.echo.menu.MenuLayout.Button.*;

public class MenuLayoutTest {
    public static void main(String[] args) {
        var expected = new MenuLayout.Button[] {
            WORLD,WORLD,WORLD,ACCESSORIES,ACCESSORIES,ACCESSORIES,CASES,CASES,CASES,
            WORLD,WORLD,WORLD,ACCESSORIES,ACCESSORIES,ACCESSORIES,CASES,CASES,CASES,
            WORLD,WORLD,WORLD,LOBBY,LOBBY,LOBBY,CASES,CASES,CASES,
            FARMS,FARMS,FARMS,LOBBY,LOBBY,LOBBY,END,END,END,
            FARMS,FARMS,FARMS,LOBBY,LOBBY,LOBBY,END,END,END,
            FARMS,FARMS,FARMS,LOBBY,LOBBY,LOBBY,END,END,END
        };
        for (int i = 0; i < 54; i++) {
            if (MenuLayout.buttonAt(i) != expected[i]) throw new AssertionError("Wrong button: " + i);
        }
        for (int slot : new int[] {-999,-1,54,55,89,90,Integer.MAX_VALUE}) {
            if (MenuLayout.buttonAt(slot) != NONE) throw new AssertionError("Player inventory/outside is clickable");
        }
        System.out.println("PASS: 54 menu slots and outside/player-inventory boundaries");
    }
}
